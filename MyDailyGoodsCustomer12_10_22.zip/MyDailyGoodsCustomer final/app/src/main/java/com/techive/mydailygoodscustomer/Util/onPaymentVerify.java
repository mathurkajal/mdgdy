package com.techive.mydailygoodscustomer.Util;

public interface onPaymentVerify {

   void PaymentSuccessful(String s);
}
