package com.techive.mydailygoodscustomer.Util;

public interface CartInterface {

    void showBadgeOnCart(int qty);
}
